# SpotifyUtil
SpotifyUtils is a very useful library made over Spotipy to automate some rather tiring tasks.

## Features
- Add songs to a playlist/album (creates one if name is provided instead of playlist url)
- Add songs to a playlist/album from a text file if it has the tracks' name and artist ("Name - Artist" format) in a newline separated way.
- Removes duplicates while adding songs if the flag is set to true.