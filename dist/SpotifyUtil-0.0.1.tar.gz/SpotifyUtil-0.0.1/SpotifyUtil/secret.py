client_id = "7214d90460af4f26a805e1132e1f8d9d"
client_secret = "bc076ca4972c47fda59d3ff24e9d2e02"
redirect_uri = "http://127.0.0.1:5500/"